package it.unipi.aide.preprocessing;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import it.unipi.aide.DAOs.DocumentsDatabaseDAOs.DocumentDatabaseDAO;
import it.unipi.aide.utilities.RandomGen;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class DatafinitiDatasetPreprocessing {

    private static DocumentDatabaseDAO connection = null;
    private static MongoDatabase database = null;

    public DatafinitiDatasetPreprocessing(DocumentDatabaseDAO connection, MongoDatabase database) {
        this.connection = connection;
        this.database = database;
    }

    @SuppressWarnings("unchecked")
    public void retrieveFile() {

        JSONParser parser = new JSONParser();

        Object rawFile;
        try {
            rawFile = parser.parse(new FileReader("raw-data-datafiniti-hotels.json"));

            JSONArray rawData = (JSONArray) rawFile;
            rawData.forEach(rawObj ->
            {
                parseReviewObject((JSONObject) rawObj);
                parsePlaceObject((JSONObject) rawObj);
                parseUserObject((JSONObject) rawObj);
            });

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void parseReviewObject(JSONObject rawRev) {

        MongoCollection<Document> reviewsColl = database.getCollection("reviews");

        //Retrieve the details of the review
        String dateS = (String) rawRev.get("reviews.date");
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(dateS);
        } catch (ParseException e) {
            try {
                date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(dateS);
            } catch (ParseException parseException) {
                parseException.printStackTrace();
            }
        }

        double rate;
        try {
            Long rating = (Long) rawRev.get("reviews.rating");
            rate = rating.doubleValue();
        } catch (ClassCastException cce) {
            rate = (Double) rawRev.get("reviews.rating");
        }
        String text = (String) rawRev.get("reviews.text");
        String title = (String) rawRev.get("reviews.title");
        String user = (String) rawRev.get("reviews.username");
        String place_id = (String) rawRev.get("id");
        String place_name = (String) rawRev.get("name");
        String place_category = (String) rawRev.get("Accommodation & Food Services");
        boolean polarity = rate >= 3;

        //Create a new review
        Document review = new Document("date", date)
                .append("rate", rate)
                .append("polarity", polarity)
                .append("text", text)
                .append("title", title)
                .append("user", user)
                .append("place_id", place_id)
                .append("place_name", place_name)
                .append("place_category", place_category);

        //Insert the new object into MongoDB
        reviewsColl.insertOne(review);
    }

    private void parsePlaceObject(JSONObject rawProd) {

        //Retrieve the ID of the place
        String id = (String) rawProd.get("id");

        //Check if the place is already present in the database
        MongoCollection<Document> placesColl = database.getCollection("places");
        boolean insert = connection.isNewID(placesColl, id);

        if (insert) {

            //Retrieve the details of the place
            String name = (String) rawProd.get("name");
            String address = (String) rawProd.get("address");
            String[] categories = ((String) rawProd.get("categories")).split(",");
            String mainCategory = "Accommodation & Food Services";
            String location = rawProd.get("country") + " - " + rawProd.get("city");
            Double latitude = (Double) rawProd.get("latitude");
            Double longitude = (Double) rawProd.get("longitude");
            String website = (String) rawProd.get("websites");

            ArrayList<String> catsList = new ArrayList<>(Arrays.asList(categories));
            ArrayList<String> reviewsList = new ArrayList<>();


            //Create a new place
            Document product = new Document("_id", id)
                    .append("name", name)
                    .append("address", address)
                    .append("categories", catsList)
                    .append("mainCategory", mainCategory)
                    .append("location", location)
                    .append("latitude", latitude.toString())
                    .append("longitude", longitude.toString())
                    .append("recentRate", 0.0)
                    .append("recentReviews", reviewsList)
                    .append("website", website);

            //Insert the new place into MongoDB
            placesColl.insertOne(product);
        }
    }

    private void parseUserObject(JSONObject rawUsr) {

        //Retrieve the user of the product
        String username = (String) rawUsr.get("reviews.username");

        //Check if the user is already present in the database
        MongoCollection<Document> usersColl = database.getCollection("users");
        boolean insert = connection.isNewID(usersColl, username);

        if (insert) {

            //Create a new user
            Document user = new Document("username", username)
                    .append("password", RandomGen.generateRandomString(8))
                    .append("city", rawUsr.get("reviews.userCity"))
                    .append("province", rawUsr.get("reviews.userProvince"))
                    .append("type", "NORMAL");

            //Insert the new object into MongoDB
            usersColl.insertOne(user);
        }
    }
}
