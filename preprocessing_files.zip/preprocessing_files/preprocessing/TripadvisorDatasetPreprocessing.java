package it.unipi.aide.preprocessing;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import it.unipi.aide.Beans.Review;
import it.unipi.aide.DAOs.DocumentsDatabaseDAOs.DocumentDatabaseDAO;
import it.unipi.aide.utilities.RandomGen;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class TripadvisorDatasetPreprocessing {
    private static DocumentDatabaseDAO connection = null;
    private static MongoDatabase database = null;

    public TripadvisorDatasetPreprocessing(DocumentDatabaseDAO connection, MongoDatabase database) {
        this.connection = connection;
        this.database = database;
    }

    @SuppressWarnings("unchecked")
    public void retrieveMuseums() {

        JSONParser parser = new JSONParser();

        Object rawMuseums;
        try {
            rawMuseums = parser.parse(new FileReader("raw-data-tripadvisor-museums-data.json"));

            JSONArray rawData = (JSONArray) rawMuseums;
            rawData.forEach(rawObj -> {
                parseMuseumObject((JSONObject) rawObj);
            });

        } catch (
                Exception exception) {
            exception.printStackTrace();
        }

    }

    private void parseMuseumObject(JSONObject rawPlace) {

        MongoCollection<Document> placesColl = database.getCollection("places");

        String id = null;
        boolean insert = false;
        while (!insert) {
            //Generate the ID of the place
            id = RandomGen.generateRandomString(10);

            //Check if the ID is already present in the database
            insert = connection.isNewID(placesColl, id);
        }

        //Retrieve the details of the place
        String name = (String) rawPlace.get("MuseumName");
        String address = (String) rawPlace.get("Address");
        String mainCategory = "Museums";
        String latitude = (String) rawPlace.get("Latitude");
        String longitude = (String) rawPlace.get("Langitude");
        String telephone = (String) rawPlace.get("PhoneNum");

        ArrayList<Review> reviewsList = new ArrayList<>();

        //Create a new place
        Document product = new Document("_id", id)
                .append("name", name)
                .append("address", address)
                .append("mainCategory", mainCategory)
                .append("recentRate", 0.0)
                .append("recentReviews", reviewsList)
                .append("latitude", latitude)
                .append("longitude", longitude)
                .append("telephone", telephone);

        //Insert the new place into MongoDB
        placesColl.insertOne(product);

        parseMuseumReviews(id, name, mainCategory);
    }

    private void parseMuseumReviews(String id, String name, String category) {

        MongoCollection<Document> reviewsColl = database.getCollection("reviews");

        JSONParser parser = new JSONParser();

        Object rawFile;
        try {
            rawFile = parser.parse(new FileReader("raw-data-tripadvisor-museums-reviews.json"));

            JSONObject rawData = (JSONObject) rawFile;

            JSONArray list = (JSONArray) rawData.get(name);

            if (list != null) {
                Iterator i = list.iterator();
                while (i.hasNext()) {
                    Date date = RandomGen.generateRandomDate();
                    double rate = RandomGen.generateRandomRate();
                    Boolean polarity = rate >= 3;
                    String text = (String) i.next();
                    String title = "My opinion about the place";
                    String user = RandomGen.returnRandomUsername(database);
                    String place_id = id;
                    String place_name = name;
                    String place_category = category;

                    //Create a new review
                    Document review = new Document("date", date)
                            .append("rate", rate)
                            .append("polarity", polarity)
                            .append("text", text)
                            .append("title", title)
                            .append("user", user)
                            .append("place_id", place_id)
                            .append("place_name", place_name)
                            .append("place_category", place_category);

                    //Insert the new object into MongoDB
                    reviewsColl.insertOne(review);
                }
            }

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void retrieveRestaurants() {

        JSONParser parser = new JSONParser();

        Object rawRestaurants;
        try {
            rawRestaurants = parser.parse(new FileReader("raw-data-tripadvisor-restaurants.json"));

            JSONArray rawData = (JSONArray) rawRestaurants;
            rawData.forEach(rawObj -> {
                parseRestaurantObject((JSONObject) rawObj);
            });

        } catch (
                Exception exception) {
            exception.printStackTrace();
        }

    }

    private void parseRestaurantObject(JSONObject rawPlace) {

        MongoCollection<Document> placesColl = database.getCollection("places");

        String id = null;
        boolean insert = false;
        while (!insert) {
            //Generate the ID of the place
            id = RandomGen.generateRandomString(10);

            //Check if the ID is already present in the database
            insert = connection.isNewID(placesColl, id);
        }

        //Retrieve the details of the place
        String name = (String) rawPlace.get("Name");
        String location = (String) rawPlace.get("City");
        String mainCategory = "Restaurants";

        ArrayList<String> reviewsList = new ArrayList<>();

        //Create a new place
        Document product = new Document("_id", id)
                .append("name", name)
                .append("location", location)
                .append("recentRate", 0.0)
                .append("recentReviews", reviewsList)
                .append("mainCategory", mainCategory);

        //Insert the new place into MongoDB
        placesColl.insertOne(product);
    }
}
