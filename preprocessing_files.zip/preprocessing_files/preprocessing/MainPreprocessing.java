package it.unipi.aide.preprocessing;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Indexes;
import com.mongodb.client.model.Sorts;
import it.unipi.aide.Beans.Review;
import it.unipi.aide.DAOs.DocumentsDatabaseDAOs.DocumentDatabaseDAO;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.json.simple.JSONArray;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Session;

import java.util.*;

public class MainPreprocessing {

    //Method to find the 10 most recent reviews for a place
    public static ArrayList<Review> findRecentReviewsOfAPlace(MongoDatabase database, String place) {

        MongoCollection<Document> reviewsColl = database.getCollection("reviews");

        ArrayList<Review> result = new ArrayList<>();

        for (Document d : reviewsColl.aggregate(
                Arrays.asList(
                        Aggregates.match(Filters.eq("place_id", place)),
                        Aggregates.sort(Sorts.descending("date")),
                        Aggregates.limit(10)
                )
        )) {
            Review r = new Review(d.getObjectId("_id").toString(), d.getDate("date"), d.getDouble("rate"), d.getBoolean("polarity"), d.getString("text"), d.getString("title"), d.getString("user"), d.getString("place_id"), d.getString("place_name"), d.getString("place_category"));
            result.add(r);
        }
        return result;
    }

    //Method to create a JSONArray of recent reviews
    private static JSONArray buildJsonFromReviewsArray(ArrayList<Review> arrayList) {

        JSONArray jsonArray = new JSONArray();

        for (Review r : arrayList) {
            //Create a review document
            Document review = new Document("_id", new ObjectId(r.getId()))
                    .append("date", r.getDate())
                    .append("rate", r.getRate())
                    .append("polarity", r.isPolarity())
                    .append("text", r.getText())
                    .append("title", r.getTitle())
                    .append("user", r.getUser());

            jsonArray.add(review);
        }

        return jsonArray;
    }

    //Method to add the 10 most recent reviews to each place
    public static void completeAllPlaces(MongoDatabase mongoDB) {

        MongoCollection<Document> placesColl = mongoDB.getCollection("places");

        for (Document d : placesColl.find()) {
            ArrayList<Review> recentReviews = findRecentReviewsOfAPlace(mongoDB, d.getString("_id"));

            JSONArray jsonList = buildJsonFromReviewsArray(recentReviews);

            BasicDBObject searchQuery = new BasicDBObject("_id", d.getString("_id"));
            BasicDBObject updateFields = new BasicDBObject();
            updateFields.append("recentReviews", jsonList);
            updateFields.append("recentRate", computeMeanRecentRates(recentReviews));
            BasicDBObject setQuery = new BasicDBObject();
            setQuery.append("$set", updateFields);
            placesColl.updateOne(searchQuery, setQuery);
        }
    }

    //Method to compute the mean of the recent rates of a place
    private static double computeMeanRecentRates(ArrayList<Review> recentReviews) {
        double sum = 0.0;
        if (!recentReviews.isEmpty()) {
            for (Review r : recentReviews) {
                sum += r.getRate();
            }
            return Math.round(sum / recentReviews.size() * 100.0) / 100.0;
        }
        return sum;
    }

    //Method to insert all the initial relationships into the graph database
    private static void setupGraphDatabase(MongoCollection<Document> reviews) {

        Driver driver = null;
        Session session = null;
        try {
            driver = GraphDatabase.driver("bolt://172.16.3.145:7687", AuthTokens.basic("neo4j", "superneo"));
            session = driver.session();
            session.run("CREATE INDEX ON:user(name)");
        } catch (Exception e) {
            System.out.println("Connection error");
        }

        for (Document d : reviews.find()) {
            //Add the user to the graph if not exists
            Map<String, Object> params = new HashMap<>();
            params.put("username", d.get("user"));
            try {
                assert session != null;
                session.run("MERGE (n:user {name: $username}) RETURN n", params);
            } catch (Exception e) {
                System.out.println("There was not possible to add the user, try again");
            }

            //Add the place to the graph if not exists
            params = new HashMap<>();
            params.put("name", d.get("place_name"));
            params.put("category", d.get("place_category"));
            params.put("id", d.get("place_id"));
            try {
                session.run("MERGE (n:place {name: $name,category: $category, ID: $id}) RETURN n", params);
            } catch (Exception e) {
                System.out.println("There was not possible to add the place, try again");
            }

            //Add the review to the graph
            params = new HashMap<>();
            params.put("username", d.get("user"));
            params.put("placeID", d.get("place_id"));
            params.put("polarity", d.get("polarity"));
            params.put("id", d.getObjectId("_id").toString());
            try {
                session.run("MATCH (n:user),(p:place) WHERE n.name=$username and p.ID=$placeID  CREATE ((n)-[r:reviewed{polarity:$polarity,ID:$id}]->(p))", params);
            } catch (Exception e) {
                System.out.println("There was not possible to add the relationship to the database, try again");
            }
        }

        assert session != null;
        session.close();
        driver.close();
    }

    public static void main(String[] args) {

        DocumentDatabaseDAO connection = new DocumentDatabaseDAO();
        //connection.openConnection("mongodb://localhost:27017");
        connection.openConnection("mongodb://172.16.3.145:27020,172.16.3.146:27020,172.16.3.102:27020/" + "retryWrites=true&w=2&wtimeout=10000&readPreference=primary");

        MongoDatabase database = connection.getMongoDatabase();

        //To speed up the place search by key words
        //database.getCollection("places").createIndex(Indexes.text("name"));

        //To speed up the computation when searching a user by username
        //database.getCollection("users").createIndex(Indexes.ascending("username"));

        //To speed up the computation when searching a review by username
        //database.getCollection("reviews").createIndex(Indexes.ascending("user"));


        //DatafinitiDatasetPreprocessing datafinitiDatasetPreprocessing = new DatafinitiDatasetPreprocessing(connection, database);
        //datafinitiDatasetPreprocessing.retrieveFile();

        //TripadvisorDatasetPreprocessing tripadvisorDatasetPreprocessing = new TripadvisorDatasetPreprocessing(connection, database);
        //tripadvisorDatasetPreprocessing.retrieveMuseums();

        //completeAllPlaces(database);

        //tripadvisorDatasetPreprocessing.retrieveRestaurants();


        //OtherMuseumsDatasetPreprocessing otherMuseumsDatasetPreprocessing = new OtherMuseumsDatasetPreprocessing(connection, database);
        //otherMuseumsDatasetPreprocessing.retrieveFile();

        //Users added at the end for testing the application
        /*Document admin = new Document("username", "admin")
                .append("password", "admin")
                .append("type", "ADMIN");
        Document coord1 = new Document("username", "coord1")
                .append("password", "coord1")
                .append("type", "COORD");
        Document coord2 = new Document("username", "coord2")
                .append("password", "coord2")
                .append("type", "COORD");
        Document coord3 = new Document("username", "coord3")
                .append("password", "coord3")
                .append("type", "COORD");
        Document normal = new Document("username", "normal")
                .append("password", "normal")
                .append("type", "NORMAL");

        MongoCollection<Document> usersColl = database.getCollection("users");
        usersColl.insertOne(admin);
        usersColl.insertOne(coord1);
        usersColl.insertOne(coord2);
        usersColl.insertOne(coord3);
        usersColl.insertOne(normal);*/

        setupGraphDatabase(database.getCollection("reviews"));

        connection.closeConnection();
    }
}
