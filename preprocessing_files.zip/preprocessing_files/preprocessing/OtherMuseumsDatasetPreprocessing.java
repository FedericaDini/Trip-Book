package it.unipi.aide.preprocessing;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import it.unipi.aide.Beans.Review;
import it.unipi.aide.DAOs.DocumentsDatabaseDAOs.DocumentDatabaseDAO;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.ArrayList;

public class OtherMuseumsDatasetPreprocessing {

    private static DocumentDatabaseDAO connection = null;
    private static MongoDatabase database = null;

    public OtherMuseumsDatasetPreprocessing(DocumentDatabaseDAO connection, MongoDatabase database) {
        this.connection = connection;
        this.database = database;
    }

    @SuppressWarnings("unchecked")
    public void retrieveFile() {

        JSONParser parser = new JSONParser();

        Object rawFile;
        try {
            rawFile = parser.parse(new FileReader("raw-data-museums.json"));

            JSONArray rawData = (JSONArray) rawFile;
            rawData.forEach(rawObj -> parsePlaceObject((JSONObject) rawObj));

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void parsePlaceObject(JSONObject rawProd) {

        //Retrieve the ID of the place
        String id = rawProd.get("Museum ID").toString();

        //Check if the place is already present in the database
        MongoCollection<Document> placesColl = database.getCollection("places");
        boolean insert = connection.isNewID(placesColl, id);

        if (insert) {

            //Retrieve the details of the place
            String name = (String) rawProd.get("Museum Name");
            String address = (String) rawProd.get("Street Address (Physical Location)");
            String mainCategory = "Museums";
            String location = rawProd.get("State (Physical Location)") + " - " + rawProd.get("City (Physical Location)");
            String telephone = (String) rawProd.get("Phone Number");

            ArrayList<String> catsList = new ArrayList<>();
            catsList.add((String) rawProd.get("Museum Type"));

            ArrayList<Review> reviewsList = new ArrayList<>();

            //Create a new place
            Document place = new Document("_id", id)
                    .append("name", name)
                    .append("address", address)
                    .append("categories", catsList)
                    .append("mainCategory", mainCategory)
                    .append("location", location)
                    .append("recentRate", 0.0)
                    .append("recentReviews", reviewsList)
                    .append("telephone", telephone);

            try {
                Double latitude = (Double) rawProd.get("Latitude");
                Double longitude = (Double) rawProd.get("Longitude");
                if (latitude != null | longitude != null) {
                    place.append("latitude", latitude.toString()).append("longitude", longitude.toString());
                }
            } catch (ClassCastException cce) {
                Long latitude = (Long) rawProd.get("Latitude");
                Long longitude = (Long) rawProd.get("Longitude");
                if (latitude != null | longitude != null) {
                    place.append("latitude", latitude.toString()).append("longitude", longitude.toString());
                }
            }


            //Insert the new place into MongoDB
            placesColl.insertOne(place);
        }
    }
}
